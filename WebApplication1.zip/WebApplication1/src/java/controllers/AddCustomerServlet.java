/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import dao.GuitarsDAO;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Customer;

@WebServlet("/add-customer")
public class AddCustomerServlet extends HttpServlet {
    
    @EJB
    private GuitarsDAO dao;

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Customer customer = new Customer();
        customer.setName(req.getParameter("name"));
        customer.setSurname(req.getParameter("surname"));
        customer.setEmail(req.getParameter("email"));
        customer.setCity(req.getParameter("city"));
        dao.saveCustomer(customer);
        
        resp.sendRedirect("index.html");
    }
    
    
    
}
