/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import javax.ejb.Local;
import model.Customer;
import model.Order;
import model.Producer;
import model.Product;
import model.Shipment;


@Local
public interface GuitarsDAO {
    
    public void saveCustomer(Customer customer);
    public void editCustomer(Customer customer);
    public Customer getCustomer(int id);
    public List<Customer> getCustomerList();
    public void deleteCustomer(int id);
    
    public void addProduct(Product product);
    public void editProduct(Product product);
    public Product getProduct(int id);
    public List<Product> readProductList();
    public void deleteProduct(int id);
    
    public void addProducer(Producer producer);
    public List<Producer> readProducerList();
    
    public void addShippingMethod(Shipment shipment);
    
    public void saveAnOrder(Order order);
    public void editOrder(Order order);
    public Order getOrder(int id);
}
