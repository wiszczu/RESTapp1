/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.util.List;
import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import model.Customer;
import model.Order;
import model.Producer;
import model.Product;
import model.Shipment;

@Stateless
@Local(GuitarsDAO.class)
public class JpaGuitarsDAOImpl implements GuitarsDAO {

    @PersistenceContext(unitName = "guitarsPU")
    private EntityManager em;

    @Override
    public void saveCustomer(Customer customer) {
        em.persist(customer);
    }

    @Override
    public void editCustomer(Customer customer) {
        em.merge(customer);
    }

    @Override
    public List<Customer> getCustomerList() {
        return em.createQuery("SELECT c from Customer c", Customer.class).getResultList();
    }

    @Override
    public Customer getCustomer(int id) {
        return em.find(Customer.class, id);
    }

    @Override
    public void deleteCustomer(int id) {
        Customer customer = em.find(Customer.class, id);
        if (customer != null) {
            em.remove(customer);
        }
    }

    @Override
    public void addProduct(Product product) {
        em.persist(product);
    }

    @Override
    public void editProduct(Product product) {
        em.merge(product);
    }

    @Override
    public Product getProduct(int id) {
        return em.find(Product.class, id);
    }

    @Override
    public List<Product> readProductList() {
        return em.createQuery("SELECT p from Product p", Product.class).getResultList();
    }

    @Override
    public void deleteProduct(int id) {
        Product product = em.find(Product.class, id);
        if (product != null) {
            em.remove(product);
        }
    }

    @Override
    public void addProducer(Producer producer) {
        em.persist(producer);
    }

    @Override
    public List<Producer> readProducerList() {
        return em.createQuery("SELECT p from Producer p", Producer.class).getResultList();
    }

    @Override
    public void addShippingMethod(Shipment shipment) {
        em.persist(shipment);
    }

    @Override
    public void saveAnOrder(Order order) {
        em.persist(order);
    }

    @Override
    public void editOrder(Order order) {
        em.merge(order);
    }

    @Override
    public Order getOrder(int id) {
        return em.find(Order.class, id);
    }
    
    

}
