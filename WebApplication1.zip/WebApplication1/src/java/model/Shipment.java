/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="shipment")
public class Shipment {
    
    @Id
    @GeneratedValue
    private int id;
    private String shippingMethod;
    private int shipDuration;
    private double shippingCost;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getShippingMethod() {
        return shippingMethod;
    }

    public void setShippingMethod(String shippingMethod) {
        this.shippingMethod = shippingMethod;
    }

    public int getDuration() {
        return shipDuration;
    }

    public void setDuration(int duration) {
        this.shipDuration = duration;
    }

    public double getShippingCost() {
        return shippingCost;
    }

    public void setShippingCost(double shippingCost) {
        this.shippingCost = shippingCost;
    }

    @Override
    public String toString() {
        return "Shipment{" + "id=" + id + ", shippingMethod=" + shippingMethod + ", duration=" + shipDuration + ", shippingCost=" + shippingCost + '}';
    }
    
    
}
