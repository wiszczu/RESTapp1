/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rs;

import dao.GuitarsDAO;
import java.util.List;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import model.Customer;

/**
 *
 * @author twiszynski
 */

@Path(value="customers")
@ApplicationScoped
public class CustomerService {
    
    @Inject
    private GuitarsDAO dao;
    
    @GET
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response getCustomers() {
        List<Customer> customers = dao.getCustomerList();
        GenericEntity<List<Customer>> entity = new GenericEntity<List<Customer>>(customers) {
        };
        return Response.ok(entity).build();
    }
    
    @GET
    @Produces({MediaType.TEXT_PLAIN})
    public Response getTxtCustomers() {
        List<Customer> customers = dao.getCustomerList();
        String report = customers.stream().map(Customer::toString).map(p -> p + "\n").reduce("", String::concat);
        return Response.ok(report).build();
    }
    
    @GET
    @Path("{id:\\d+}")
    @Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
    public Response getCustomer(@PathParam("id") String id) {
        int customerId = Integer.parseInt(id);
        Customer customer = dao.getCustomer(customerId);
        return Response.ok(customer).build();
    }
    
    
    
}
